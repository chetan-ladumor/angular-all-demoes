import { AppError } from "src/app/common/app-error";

export class BadInput extends AppError {
    
}