export class CoursesSerive{
    getCourses() {
        return ["Course1","Courses2"];
    }
}