import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route-app',
  templateUrl: './route-app.component.html',
  styleUrls: ['./route-app.component.css']
})
export class RouteAppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
